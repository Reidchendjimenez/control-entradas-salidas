import flet as ft
from sqlalchemy import text
from usr.database.base import get_db_adaptive
from usr.notifications import show_success, show_error, show_warning, show_info
from usr.views.configuracion.helpers import _colors


def build_sistema_tab(view):
    colors = _colors(view.page)
    return ft.Container(
        content=ft.Column([
            ft.Container(height=20),
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Container(
                                content=ft.Icon(ft.Icons.DASHBOARD, color=colors['white'], size=28),
                                bgcolor=colors['accent_dark'],
                                padding=12,
                                border_radius=12,
                            ),
                            ft.Column([
                                ft.Text("Mantenimiento del Sistema", weight=ft.FontWeight.BOLD, size=16),
                                ft.Text("Herramientas de diagnostico y configuracion", size=12, color=colors['text_secondary']),
                            ], spacing=2),
                        ], spacing=15),
                        ft.Divider(height=20, color=colors['border']),
                        ft.Text(
                            "Si experimenta errores tras actualizaciones o cambios de configuracion, use 'Probar Conexion' para verificar la base de datos.",
                            size=13,
                            color="#424242",
                        ),
                        ft.ElevatedButton(
                            "Probar Conexion",
                            on_click=lambda e: test_connection_action(view, e),
                            icon=ft.Icons.STORAGE,
                            bgcolor="#7B1FA2",
                            color=colors['white'],
                        ),
                        ft.Container(height=5),
                        ft.Text(
                            "Use 'Verificar Supabase' para comprobar la conexión real con la base de datos remota (nube).",
                            size=13,
                            color="#424242",
                        ),
                        ft.ElevatedButton(
                            "Verificar Supabase",
                            on_click=lambda e: test_supabase_action(view, e),
                            icon=ft.Icons.CLOUD_DONE,
                            bgcolor="#1565C0",
                            color=colors['white'],
                        ),
                        ft.Divider(height=20, color=colors['border']),
                        ft.Text(
                            "Configuracion de Alertas",
                            weight=ft.FontWeight.BOLD,
                            size=14
                        ),
                        ft.Text(
                            "Habilite las notificaciones para recibir alertas de stock bajo y validaciones en tiempo real.",
                            size=12,
                            color=colors['text_secondary'],
                        ),
                        ft.ElevatedButton(
                            "Habilitar Notificaciones",
                            on_click=lambda e: request_notifications_action(view, e),
                            icon=ft.Icons.NOTIFICATIONS_ACTIVE,
                            bgcolor=colors['accent_dark'],
                            color=colors['white'],
                        ),
                        ft.Container(
                            content=view.test_result_text,
                            padding=10,
                            bgcolor=colors['bg'],
                            border_radius=8,
                            visible=False,
                        ),
                        ft.Divider(height=30, color=colors['border']),
                        ft.Text(
                            "Modo Offline",
                            weight=ft.FontWeight.BOLD,
                            size=14
                        ),
                        ft.Text(
                            "Active el modo offline para usar la aplicacion sin conexion a internet.",
                            size=12,
                            color=colors['text_secondary'],
                        ),
                        ft.Container(height=10),
                        ft.Row([
                            ft.Text("Estado:", size=14, color=colors['text_secondary']),
                            view.offline_status_indicator,
                        ], spacing=10),
                        ft.Container(height=10),
                        ft.ElevatedButton(
                            "Cambiar Modo",
                            on_click=lambda e: toggle_offline_mode(view, e),
                            icon=ft.Icons.WIFI_OFF,
                            bgcolor=colors['accent'],
                            color=colors['white'],
                        ),
                        ft.Divider(height=30, color=colors['border']),
                        ft.Text(
                            "Control de Inventario",
                            weight=ft.FontWeight.BOLD,
                            size=14
                        ),
                        ft.Text(
                            "Permite que las salidas dejen el stock en negativo (por defecto está desactivado).",
                            size=12,
                            color=colors['text_secondary'],
                        ),
                        ft.Container(height=10),
                        ft.Row([
                            ft.Text("Permitir stock negativo en salidas:", size=14, color=colors['text_secondary'], expand=True),
                            _build_negativo_switch(),
                        ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                        ft.Container(height=15),
                        ft.Text(
                            "Almacén por defecto para el descargo de materia prima en producciones:",
                            size=14, color=colors['text_secondary'],
                        ),
                        ft.Container(height=10),
                        _build_almacen_produccion_dd(),
                        ft.Divider(height=30, color=colors['border']),
                        ft.Text(
                            "Gestion de Operador",
                            weight=ft.FontWeight.BOLD,
                            size=14
                        ),                        ft.Text(
                            "Cambie el operador registrado en este dispositivo.",
                            size=12,
                            color=colors['text_secondary'],
                        ),
                        ft.Container(height=10),
                        ft.ElevatedButton(
                            "Cambiar operador de este dispositivo",
                            on_click=lambda e: on_cambiar_operador(view, e),
                            icon=ft.Icons.PERSON_OUTLINED,
                            bgcolor=ft.Colors.ORANGE_600,
                            color=ft.Colors.WHITE,
                        ),
                    ], spacing=15),
                    padding=25,
                ),
            ),
        ], spacing=10, scroll=ft.ScrollMode.AUTO, expand=True),
        padding=20,
        expand=True,
    )


def _build_negativo_switch():
    from usr.database.local_replica import LocalReplica

    def _on_change(e):
        valor = "1" if e.control.value else "0"
        try:
            LocalReplica.set_pos_setting('permitir_stock_negativo', valor)
            show_success("Stock negativo " + ("permitido" if e.control.value else "bloqueado") + " en salidas")
        except Exception as ex:
            show_error(f"Error al guardar la configuración: {ex}")

    try:
        val = LocalReplica.get_pos_setting('permitir_stock_negativo', '0') or '0'
        activo = str(val).strip().lower() in ('1', 'true', 'si', 'sí', 'yes')
    except Exception:
        activo = False
    return ft.Switch(value=activo, on_change=_on_change)


def _build_almacen_produccion_dd():
    from usr.database.local_replica import LocalReplica
    from usr.views.producciones.data import almacen_produccion_default

    almacenes = []
    try:
        almacenes = LocalReplica.get_almacenes() or []
    except Exception:
        almacenes = []
    if not almacenes:
        almacenes = ['principal', 'restaurante']

    def _on_select(e):
        try:
            LocalReplica.set_pos_setting('almacen_produccion', e.control.value or 'restaurante')
            show_success("Almacén de descargo de producción actualizado")
        except Exception as ex:
            show_error(f"Error al guardar la configuración: {ex}")

    actual = almacen_produccion_default()
    if actual not in almacenes:
        actual = almacenes[0]
    return ft.Dropdown(
        value=actual,
        options=[ft.dropdown.Option(a, a.capitalize()) for a in almacenes],
        on_select=_on_select,
        width=300,
    )


def test_connection_action(view, e):
    db = None
    try:
        db = next(get_db_adaptive())
        db.execute(text("SELECT 1"))
        view.test_result_text.value = "Conexion exitosa - Base de datos operativa"
        view.test_result_text.color = "#2E7D32"
        view.test_result_text.visible = True
        show_success("Conexion a base de datos verificada")
    except Exception as ex:
        view.test_result_text.value = f"Error: {str(ex)}"
        view.test_result_text.color = "#c62828"
        view.test_result_text.visible = True
        show_error(f"Error de conexion: {str(ex)}")
    finally:
        if db:
            db.close()
        view.update()


def toggle_offline_mode(view, e=None):
    from usr.database import base
    current = base.is_online()
    base._is_online = not current

    if current:
        view.offline_status_indicator.value = "FORZADO OFFLINE"
        view.offline_status_indicator.color = ft.Colors.RED_400
        show_warning("Modo offline forzado - Los datos se guardaran localmente")
    else:
        view.offline_status_indicator.value = "ONLINE"
        view.offline_status_indicator.color = ft.Colors.GREEN_400
        show_success("Conexion normal restaurada")

    view.update()


def on_cambiar_operador(view, e):
    from usr.database.local_replica import LocalReplica
    from usr.views.configuracion.dialogs import close_dialog

    usuario = LocalReplica.get_usuario_dispositivo()

    if usuario and usuario.get("pin_hash"):
        view.pin_verify_input = ft.TextField(
            label="PIN actual",
            password=True,
            max_length=4,
            keyboard_type=ft.KeyboardType.NUMBER
        )

        view.verify_dialog = ft.AlertDialog(
            title=ft.Text("Verificar PIN"),
            content=ft.Column([
                ft.Text("Ingrese su PIN actual para continuar"),
                view.pin_verify_input,
            ], tight=True),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: close_dialog(view, e)),
                ft.ElevatedButton("Verificar", on_click=lambda e: on_verificar_pin_cambio(view, e), bgcolor=ft.Colors.DEEP_PURPLE_600, color=ft.Colors.WHITE),
            ]
        )
        view.page.overlay.append(view.verify_dialog)
        view.verify_dialog.open = True
        view.page.update()
    else:
        confirmar_cambio(view)


def on_verificar_pin_cambio(view, e):
    from usr.database.local_replica import LocalReplica
    if not view.pin_verify_input.value:
        return
    if LocalReplica.verificar_pin(view.pin_verify_input.value):
        confirmar_cambio(view)
    else:
        show_error("PIN incorrecto")


def confirmar_cambio(view):
    from usr.database.local_replica import LocalReplica
    from main import main as restart_main
    from usr.views.configuracion.dialogs import close_dialog

    close_dialog(view)
    LocalReplica.eliminar_usuario_dispositivo()
    show_info("Recargando...")
    view.page.run_task(restart_main, view.page)


def test_supabase_action(view, e):
    """Lanza la verificación de Supabase en un hilo (no bloquea la UI)."""
    view.page.run_task(_do_test_supabase, view)


async def _do_test_supabase(view):
    import asyncio
    from usr.database.sync import get_sync_manager
    from usr.notifications import show_info, show_success, show_error_with_copy

    show_info("Verificando conexión con Supabase...")
    sync_mgr = get_sync_manager()
    if not sync_mgr:
        view.test_result_text.value = "SyncManager no inicializado"
        view.test_result_text.color = "#c62828"
        view.test_result_text.visible = True
        show_error_with_copy("SyncManager no inicializado", "No hay sync_mgr")
        view.update()
        return

    try:
        ok, mensaje = await asyncio.to_thread(sync_mgr.test_remote_connection)
        if ok:
            view.test_result_text.value = "Conexión exitosa con Supabase"
            view.test_result_text.color = "#2E7D32"
            view.test_result_text.visible = True
            show_success(f"Conexión a Supabase verificada")
        else:
            view.test_result_text.value = f"Supabase: {mensaje}"
            view.test_result_text.color = "#c62828"
            view.test_result_text.visible = True
            show_error_with_copy("Error de conexión a Supabase", Exception(mensaje))
    except Exception as ex:
        view.test_result_text.value = f"Supabase: {ex}"
        view.test_result_text.color = "#c62828"
        view.test_result_text.visible = True
        show_error_with_copy("Error de conexión a Supabase", ex)
    finally:
        try:
            view.update()
        except Exception:
            pass


def request_notifications_action(view, e):
    try:
        if hasattr(view.page, "overlay"):
            fcm_component = next((c for c in view.page.overlay if hasattr(c, "request_permission")), None)
            if fcm_component:
                fcm_component.request_permission()
                show_info("Solicitando permiso de notificaciones...")
            else:
                show_warning("El servicio de notificaciones no esta activo en este entorno.")
        else:
            show_error("No se pudo acceder al sistema de la aplicacion.")
    except Exception as ex:
        show_error(f"Error al activar notificaciones: {str(ex)}")
