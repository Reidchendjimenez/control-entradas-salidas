"""Diálogos del módulo Producciones: confirmar eliminar receta, descargo y cancelación.

El editor de receta se maneja en `receta_editor.py` (pantalla completa).
"""
import flet as ft

from usr.notifications import show_success, show_error, show_warning
from usr.views.producciones import data
from usr.views.producciones.helpers import colors as _colors


def delete_receta_dialog(page, receta, on_confirmed=None):
    colors = _colors(page)

    def _confirm(e):
        try:
            dialog.open = False
            page.update()
        except Exception:
            pass
        try:
            data.eliminar_receta(receta['id'])
            show_success("Receta eliminada")
        except Exception as ex:
            show_error(f"Error al eliminar: {ex}")
            return
        if on_confirmed:
            on_confirmed()

    def _cancel(e):
        try:
            dialog.open = False
            page.update()
        except Exception:
            pass

    dialog = ft.AlertDialog(
        title=ft.Text("Eliminar Receta"),
        content=ft.Text(f"¿Eliminar '{receta.get('nombre')}'?"),
        actions=[
            ft.TextButton("Cancelar", on_click=_cancel),
            ft.FilledButton("Eliminar", on_click=_confirm, style=ft.ButtonStyle(bgcolor=colors['error'], color=colors['white'])),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    page.overlay.append(dialog)
    dialog.open = True
    page.update()


def descargo_dialog(page, produccion, receta, on_completed=None):
    """Diálogo para registrar el descargo de ingredientes de una producción pendiente."""
    from usr.views.producciones.data import planificar_descargo, ejecutar_descargo

    colors = _colors(page)
    items = planificar_descargo(receta, produccion)

    cantidad_fields = []
    stock_fields = []

    def _build_field_row(item):
        unidad_label = 'kg' if item['es_pesable'] else item['unidad']
        sugerida = '' if item['peso_variable'] else f"{item['cantidad_sugerida']:.2f}"

        cant_field = ft.TextField(
            value=sugerida,
            keyboard_type=ft.KeyboardType.NUMBER,
            width=120,
            suffix=ft.Text(unidad_label),
            autofocus=item['peso_variable'],
        )
        if item['peso_variable']:
            cant_field.hint_text = "Peso real (kg)"
        else:
            cant_field.disabled = False  # editable también, por si la cantidad real varía
            cant_field.hint_text = "Sugerido"

        stock_text = ft.Text("—", size=11, color=colors['text_secondary'])

        row = ft.Container(
            content=ft.Row([
                ft.Column([
                    ft.Text(item['nombre'], weight=ft.FontWeight.BOLD, color=colors['text_primary']),
                    ft.Row([
                        ft.Text(
                            f"Variable · {unidad_label}" if item['peso_variable'] else f"Sugerido · {unidad_label}",
                            size=11, color=colors['text_secondary'],
                        ),
                        ft.Text("·", size=11, color=colors['border']),
                        stock_text,
                    ], spacing=4),
                ], expand=True, spacing=2),
                cant_field,
            ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
            padding=ft.Padding.all(10),
            bgcolor=colors['card'],
            border_radius=8,
            border=ft.Border.all(1, colors['border']),
        )

        cantidad_fields.append({
            'producto_id': item['producto_id'],
            'es_pesable': item['es_pesable'],
            'almacen': item['almacen'],
            'unidad': unidad_label,
            'field': cant_field,
        })
        stock_fields.append({
            'producto_id': item['producto_id'],
            'unidad': unidad_label,
            'text': stock_text,
        })
        return row

    if not items:
        dialog = ft.AlertDialog(
            title=ft.Text("Sin ingredientes"),
            content=ft.Text("Esta receta no tiene ingredientes definidos para descargar."),
            actions=[ft.TextButton("Cerrar", on_click=lambda e: setattr(dialog, 'open', False) or page.update())],
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()
        return

    rows = [_build_field_row(i) for i in items]

    # Almacén del descargo: usa el almacén de producción configurado por defecto.
    from usr.views.producciones.data import almacen_produccion_default, productos_producidos
    from usr.database.local_replica import LocalReplica

    producidos = productos_producidos(produccion)
    if not producidos:
        producidos = [{
            'producto_id': receta.get('producto_final_id'),
            'nombre': receta.get('nombre', '?'),
            'cantidad': float(produccion.get('cantidad', 1)),
            'unidad': 'unidad',
        }]

    cocineros_field = ft.TextField(
        label="Cocineros",
        hint_text="Nombre del cocinero que realizó la producción",
        width=220,
    )

    almacenes = []
    try:
        almacenes = LocalReplica.get_almacenes() or []
    except Exception:
        almacenes = []
    if not almacenes:
        almacenes = ['principal', 'restaurante']
    almacen_default = almacen_produccion_default()
    if almacen_default not in almacenes:
        almacen_default = almacenes[0] if almacenes else 'principal'

    def _fmt_stock(cant):
        s = f"{float(cant):.2f}".rstrip('0').rstrip('.')
        return s if s else '0'

    def _actualizar_stock(almacen):
        for sf in stock_fields:
            cant = 0.0
            try:
                exc = LocalReplica.get_existencias_by_producto_almacen(sf['producto_id'], almacen)
                if exc:
                    cant = float(exc.get('cantidad', 0) or 0)
            except Exception:
                cant = 0.0
            color = colors['error'] if cant <= 0 else colors['success']
            sf['text'].value = f"Stock disponible: {_fmt_stock(cant)} {sf['unidad']}"
            sf['text'].color = color

    almacen_dd = ft.Dropdown(
        label="Almacén",
        value=almacen_default,
        options=[ft.dropdown.Option(a, a.capitalize()) for a in almacenes],
        width=180,
        on_select=lambda e: _actualizar_stock(e.control.value),
    )

    producidos_list = ft.Column([
        *[
            ft.Row([
                ft.Icon(ft.Icons.CHECK_CIRCLE_OUTLINE, size=16, color=colors['success']),
                ft.Text(p['nombre'], size=12, color=colors['text_primary'], weight=ft.FontWeight.BOLD, expand=True),
                ft.Text(f"{p['cantidad']:.2f}".rstrip('0').rstrip('.') + f" {p['unidad']}".rstrip(),
                        size=12, color=colors['accent'], weight=ft.FontWeight.BOLD),
            ], spacing=6, vertical_alignment=ft.CrossAxisAlignment.CENTER)
        for p in producidos
    ]], spacing=4)

    content = ft.Column([
        ft.Text(
            f"Receta: {receta.get('nombre', '')} · Producción #{produccion['id']}",
            weight=ft.FontWeight.BOLD, color=colors['text_primary'],
        ),
        ft.Row([
            ft.Text('Cantidades producidas:', size=12, color=colors['text_secondary'], weight=ft.FontWeight.BOLD),
            ft.Container(expand=True),
            ft.Text('Almacén:', size=12, color=colors['text_secondary']),
            almacen_dd,
        ], spacing=6, vertical_alignment=ft.CrossAxisAlignment.CENTER),
        producidos_list,
        ft.Row([
            ft.Text('Cocineros:', size=12, color=colors['text_secondary']),
            cocineros_field,
        ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
        ft.Divider(height=1, color=colors['border']),
        ft.Text(
            'Ingresa el peso/cantidad real usado de cada ingrediente:',
            size=12, color=colors['text_secondary'],
        ),
        *rows,
    ], spacing=10, scroll=ft.ScrollMode.ALWAYS, height=400)

    def _confirmar(e):
        items_cantidades = []
        errores = []
        almacen_salida = almacen_dd.value or almacenes[0] if almacenes else 'principal'
        for entry in cantidad_fields:
            try:
                cantidad = float((entry['field'].value or '').replace(',', '.').strip() or 0)
            except ValueError:
                errores.append(f"Cantidad inválida para producto {entry['producto_id']}")
                continue
            if cantidad <= 0:
                errores.append(f"Cantidad debe ser > 0 para producto {entry['producto_id']}")
                continue
            items_cantidades.append({
                'producto_id': entry['producto_id'],
                'cantidad': cantidad,
                'es_pesable': entry['es_pesable'],
                'almacen': almacen_salida,
                'unidad': entry['unidad'],
            })
        if errores:
            show_error("\n".join(errores))
            return

        try:
            ok, errs = ejecutar_descargo(page, produccion, receta, items_cantidades, cocineros=cocineros_field.value or None)
        except Exception as ex:
            show_error(f"Error al ejecutar descargo: {ex}")
            return
        if not ok:
            show_error("No se pudo completar el descargo:\n" + "\n".join(f"• {e}" for e in errs))
            return

        try:
            dialog.open = False
            page.update()
        except Exception:
            pass
        show_success(f"Producción #{produccion['id']} completada")
        if on_completed:
            on_completed()

    def _cancel(e):
        try:
            dialog.open = False
            page.update()
        except Exception:
            pass

    dialog = ft.AlertDialog(
        title=ft.Text("Descargar Producción", weight=ft.FontWeight.BOLD),
        content=content,
        actions=[
            ft.TextButton("Cancelar", on_click=_cancel),
            ft.FilledButton("Confirmar Descargo", on_click=_confirmar),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    page.overlay.append(dialog)
    dialog.open = True
    page.update()
    _actualizar_stock(almacen_dd.value or almacen_default)


def cancelar_produccion_dialog(page, produccion, receta, on_confirmed=None):
    """Confirma cancelación + revierte el stock del producto final."""
    from usr.views.producciones.data import cancelar_produccion

    colors = _colors(page)

    def _confirm(e):
        try:
            dialog.open = False
            page.update()
        except Exception:
            pass
        try:
            cancelar_produccion(page, produccion, receta)
            show_success(f"Producción #{produccion['id']} cancelada y stock revertido")
        except Exception as ex:
            show_error(f"Error al cancelar: {ex}")
            return
        if on_confirmed:
            on_confirmed()

    def _cancel(e):
        try:
            dialog.open = False
            page.update()
        except Exception:
            pass

    dialog = ft.AlertDialog(
        title=ft.Text("Cancelar Producción", weight=ft.FontWeight.BOLD),
        content=ft.Text(
            f"¿Cancelar la producción #{produccion['id']} de '{receta.get('nombre', '')}'?\n\n"
            "Se revertirá el stock del producto final (la entrada original se anula)."
        ),
        actions=[
            ft.TextButton("No cancelar", on_click=_cancel),
            ft.FilledButton("Sí, cancelar", on_click=_confirm, style=ft.ButtonStyle(bgcolor=colors['error'], color=colors['white'])),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    page.overlay.append(dialog)
    dialog.open = True
    page.update()
