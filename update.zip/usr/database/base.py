"""
Base de datos - SQLite como única fuente de verdad.
El sistema ahora funciona offline-first con SQLite local.
"""
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, declarative_base
from config.config import get_settings

_base = None
_local_engine = None
_local_session_local = None
_last_engine_url = None

def get_base():
    global _base
    if _base is None:
        _base = declarative_base()
    return _base

def get_local_engine():
    """Obtiene el motor de la base de datos local SQLite.
    Recrea el motor si la ruta de la BD cambió (set_db_path)."""
    global _local_engine, _local_session_local, _last_engine_url
    settings = get_settings()
    current_url = settings.LOCAL_DATABASE_URL
    if _local_engine is None or current_url != _last_engine_url:
        _local_engine = create_engine(current_url, future=True)
        _local_session_local = None
        _last_engine_url = current_url
    return _local_engine

def get_session():
    """Obtiene sessionmaker para SQLite local."""
    global _local_session_local
    if _local_session_local is None:
        _local_session_local = sessionmaker(bind=get_local_engine(), autoflush=False, autocommit=False)
    return _local_session_local

def get_db():
    """Generator que proporciona una sesión SQLite local.
    Esta es la única fuente de verdad."""
    db = get_session()()
    try:
        yield db
    finally:
        db.close()

def get_db_adaptive():
    """Generator que proporciona una sesión SQLite local."""
    session = get_session()
    db = session()
    try:
        yield db
    finally:
        db.close()

# Alias de compatibilidad para código existente
def get_engine():
    """Alias de get_local_engine() para compatibilidad."""
    return get_local_engine()

def get_session_local():
    """Alias de get_session() para compatibilidad."""
    return get_session()

def get_local_session():
    """Alias de get_session() para compatibilidad."""
    return get_session()

def get_local_db():
    """Alias de get_session() para compatibilidad."""
    return get_session()

def check_connection() -> bool:
    """Verifica si hay conexión a internet (solo para indicador visual).
    No bloquea operaciones - SQLite siempre está disponible."""
    import socket
    try:
        socket.create_connection(('8.8.8.8', 53), timeout=3)
        return True
    except:
        pass
    # Fallback: intentar conexión HTTP (más fiable en Android)
    try:
        import urllib.request
        urllib.request.urlopen('https://www.google.com', timeout=3)
        return True
    except:
        return False

def is_online() -> bool:
    """Alias de check_connection() para compatibilidad."""
    return check_connection()

Base = get_base()

def init_local_tables():
    """Inicializa las tablas en la base de datos local."""
    from .local_replica import LocalReplica
    from .sync_queue import SyncQueue
    LocalReplica.create_tables()
    SyncQueue.init_queue()

def get_connection_status() -> dict:
    """Retorna el estado de conexión (solo para indicador)."""
    online = check_connection()
    from .sync_queue import get_sync_queue
    queue = get_sync_queue()
    queue_status = queue.get_status()
    
    return {
        "online": online,
        "is_online": online,
        "pending_uploads": queue_status.get('pending', 0),
        "last_sync": queue_status.get('last_sync')
    }